<!DOCTYPE html>
<html lang="en">

<head>
    <?php

    include_once 'AdminLink.php';
    include_once 'AdminHome.php';

    ?>

</head>

<body>


    <div class="content-wrapper bg-white">
        <div class="content-header mt-5">
            <div class="container-fluid">
                <div class="row d-flex center mb-3">

                    <h1 style="color:black;">Admin Registration</h1>
                

                </div>

                <form id="quickForm">
                    <div class="card-body">
                        <div class="form-group">
                            <label> Name</label>
                            <input type="text" name="name" class="form-control" placeholder="Enter Name">
                        </div>
                        <div class="form-group">
                            <label>EmailID</label>
                            <input type="text" name="emailid" class="form-control" placeholder="Enter EmailID">
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="Password" name="password" class="form-control" placeholder="Enter Password">
                        </div>
                        <div class="form-group">
                            <label>Confirm Password</label>
                            <input type="Password" name="cpassword" class="form-control" placeholder="Enter Confirm Password">
                        </div>
                        <div class="form-group">
                            <label>Contact No</label>
                            <input type="text" name="contact" class="form-control" placeholder="Enter Contact No">
                        </div>
                        <div class="mb-3">
                            <label for="formFile" class="form-label">Image</label>
                            <input class="form-control" type="file" id="formFile">
                        </div>
                        <label for="formFile" class="form-label">Permission</label>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                            <label class="form-check-label" >
                                Insert
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" >
                            <label class="form-check-label" >
                                Update
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" >
                            <label class="form-check-label" >
                                Delete
                            </label>
                        </div>

                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

</body>

</html>