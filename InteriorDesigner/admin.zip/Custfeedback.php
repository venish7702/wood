<!DOCTYPE html>
<html lang="en">

<head>
    <?php

    include_once 'AdminLink.php';
    include_once 'AdminHome.php';

    ?>

</head>

<body>


    <div class="content-wrapper bg-white">
        <div class="content-header mt-5">
            <div class="container-fluid">
                 
                <div class="row d-flex center mb-3">
                     
                        <h1 style="color:black;">Customer Feedback</h1>
                        
                    
                </div>
                <table class="table bg-white ">
                    <thead>
                        <tr>
                            <th scope="col">SR NO></th>
                            <th scope="col">Product NAME</th>
                            <th scope="col">REVIEW</th>
                            <th scope="col">USER NAME</th>
                            <th scope="col">CREATED ON</th>
                            <th scope="col">RATING</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th scope="row">1</th>
                            <td>Mark</td>
                            <td>Otto</td>
                            <td>@mdo</td>
                            <td>Mark</td>
                            <td>Otto</td>
                            
                        </tr>
                        <tr>
                            <th scope="row">2</th>
                            <td>Jacob</td>
                            <td>Thornton</td>
                            <td>@fat</td>
                            <td>@fat</td>
                            <td>@fat</td>
                            
                        </tr>
                        <tr>
                            <th scope="row">3</th>
                            <td >Larry the Bird</td>
                            <td>@twitter</td>
                            <td>@twitter</td>
                            <td>@twitter</td>
                            <td>@twitter</td>
                            
                        </tr>

                        <tr>
                            <th scope="row">3</th>
                            <td >Larry the Bird</td>
                            <td>@twitter</td>
                            <td>@twitter</td>
                            <td>@twitter</td>
                            <td>@twitter</td>
                            
                        </tr>

                        <tr>
                            <th scope="row">3</th>
                            <td >Larry the Bird</td>
                            <td>@twitter</td>
                            <td>@twitter</td>
                            <td>@twitter</td>
                            <td>@twitter</td>
                            
                        </tr>

                        <tr>
                            <th scope="row">3</th>
                            <td >Larry the Bird</td>
                            <td>@twitter</td>
                            <td>@twitter</td>
                            <td>@twitter</td>
                            <td>@twitter</td>
                            
                        </tr>

                        <tr>
                            <th scope="row">3</th>
                            <td >Larry the Bird</td>
                            <td>@twitter</td>
                            <td>@twitter</td>
                            <td>@twitter</td>
                            <td>@twitter</td>
                            
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>

</html>