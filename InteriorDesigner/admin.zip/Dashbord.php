<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.no-icons.min.css" rel="stylesheet">
<link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
<link rel="stylesheet" href="path/to/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">

  <?php

  include_once './AdminLink.php';
  include_once 'AdminHome.php';

  ?>

  <style>
    .card-text{
      font-size: 25px;
    }
  </style>

</head>


<body class="hold-transition dark-mode sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">




  <div class="wrapper">

    <!-- Preloader -->
    <div class="preloader flex-column justify-content-center align-items-center">
      <img class="animation__wobble" src="dist/img/AdminLTELogo.png" alt="AdminLTELogo" height="60" width="60">
    </div>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">Dashboard v2</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active">Dashboard v2</li>
              </ol>
            </div><!-- /.col -->
          </div><!-- /.row -->



        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <!-- Info boxes -->
           

          <div class="row">
            <div class="col-sm-12  col-md-4 col-lg-4 col-xl-3">
              <div class="border border-5 card ">
                <div class="card-body">
                 <div class="d-flex justify-content-between mb-5">
                      <i class="fa fa-users fa-3x"></i>
                      <h1>2</h1>
                 </div>
                 <p class="card-text text-center">Customer</p>
                </div>
              </div>
            </div>

            <div class="col-sm-12  col-md-4 col-lg-4 col-xl-3">
            <div class="border border-5 card">
                <div class="card-body">
                 <div class="d-flex justify-content-between mb-5">
                      <i class="fa fa-users fa-3x"></i>
                      <h1>1</h1>
                 </div>
                 <p class="card-text text-center">Interior</p>
                </div>
              </div>
            </div>

            <div class="col-sm-12  col-md-4 col-lg-4 col-xl-3">
            <div class="border border-5 card">
                <div class="card-body">
                 <div class="d-flex justify-content-between mb-5">
                      <i class="icon-info-sign fa-3x"></i>
                      <h1>1</h1>
                 </div>
                 <p class="card-text text-center">Inquiry</p>
                </div>
              </div>
            </div>

            <div class="col-sm-12  col-md-4 col-lg-4 col-xl-3">
            <div class="border border-5 card">
                <div class="card-body">
                 <div class="d-flex justify-content-between mb-5">
                      <i class="icon-th-large fa-3x"></i>
                      <h1>2</h1>
                 </div>
                 <p class="card-text text-center">Product</p>
                </div>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-sm-12  col-md-4 col-lg-4 col-xl-3">
              <div class="border border-5 card">
                <div class="card-body">
                 <div class="d-flex justify-content-between mb-5">
                      <i class="icon-suitcase fa-3x"></i>
                      <h1>2</h1>
                 </div>
                 <p class="card-text text-center">Package</p>
                </div>
              </div>
            </div>

            <div class="col-sm-12  col-md-4 col-lg-4 col-xl-3">
            <div class="border border-5 card">
                <div class="card-body">
                 <div class="d-flex justify-content-between mb-5">
                      <i class="icon-shopping-cart fa-3x"></i>
                      <h1>1</h1>
                 </div>
                 <p class="card-text text-center">Order</p>
                </div>
              </div>
            </div>

            <div class="col-sm-12  col-md-4 col-lg-4 col-xl-3">
            <div class="border border-5 card">
                <div class="card-body">
                 <div class="d-flex justify-content-between mb-5">
                      <i class="fa-solid fa-message fa-3x"></i>
                      <h1>1</h1>
                 </div>
                 <p class="card-text text-center">Feedback</p>
                </div>
              </div>
            </div>

            <div class="col-sm-12  col-md-4 col-lg-4 col-xl-3">
            <div class="card border border-5">
                <div class="card-body">
                 <div class="d-flex justify-content-between mb-5">
                      <i class="fa fa-thumbs-up fa-3x"></i>
                      <h1>2</h1>
                 </div>
                 <p class="card-text text-center">Subscriber</p>
                </div>
              </div>
            </div>
          </div>

        </div><!--/. container-fluid -->
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->





  </div>



  <!-- ./wrapper -->











</body>

</html>