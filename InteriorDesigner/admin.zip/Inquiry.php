<!DOCTYPE html>
<html lang="en">

<head>
    <?php

    include_once 'AdminLink.php';
    include_once 'AdminHome.php';

    ?>

</head>

<body>


    <div class="content-wrapper bg-white">
        <div class="content-header mt-5">
            <div class="container-fluid">
                 
                <div class="row d-flex center mb-3">
                     
                        <h1 style="color:black;">Inquiry List</h1>
                        
                    
                </div>
                <table class="table bg-white ">
                    <thead>
                        <tr>
                            <th scope="col">SR NO></th>
                            <th scope="col">SUBJECT</th>
                            <th scope="col">EMAILID</th>
                            <th scope="col">REPLAY</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th scope="row">1</th>
                            <td>Mark</td>
                            <td>Otto</td>
                            <td><i class="fa-sharp fa-solid fa-check"></i></td>

                        </tr>
                        <tr>
                            <th scope="row">2</th>
                            <td>Jacob</td>
                            <td>@fat</td>
                            <td><i class="fa-sharp fa-solid fa-check"></i></td>

                        </tr>
                        <tr>
                            <th scope="row">3</th>
                            <td >Larry the Bird</td>
                            <td>@twitter</td>
                            <td><i class="fa-sharp fa-solid fa-check"></i></td>

                        </tr>

                        <tr>
                            <th scope="row">3</th>
                            <td >Larry the Bird</td>
                            <td>@twitter</td>
                            <td><i class="fa-sharp fa-solid fa-check"></i></td>

                        </tr>

                        <tr>
                            <th scope="row">3</th>
                            <td >Larry the Bird</td>
                            <td>@twitter</td>
                            <td><i class="fa-sharp fa-solid fa-check"></i></td>

                        </tr>

                        <tr>
                            <th scope="row">3</th>
                            <td >Larry the Bird</td>
                            <td>@twitter</td>
                            <td><i class="fa-sharp fa-solid fa-check"></i></td>

                        </tr>

                        <tr>
                            <th scope="row">3</th>
                            <td >Larry the Bird</td>
                            <td>@twitter</td>
                            <td><i class="fa-sharp fa-solid fa-check"></i></td>

                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>

</html>