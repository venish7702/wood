<!DOCTYPE html>
<html lang="en">

<head>
    <?php

    include_once 'AdminLink.php';
    include_once 'AdminHome.php';

    ?>

</head>

<body>


    <div class="content-wrapper bg-white">
        <div class="content-header mt-5">
            <div class="container-fluid">
                 
                <div class="row d-flex justify-content-between mb-3">
                     
                        <h1 style="color:black;">Newsletter </h1>
                         
                    
                </div>
                <table class="table bg-white ">
                    <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">EMAIL ID</th>
                            <th scope="col">SEND</th>
                           
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th scope="row">1</th>
                            <th scope="row">Tusharkhichadiya@gmail.com</th>
                            <td><i class="fa-solid fa-share"></i></td>
                            
                            
                        </tr>
                        <tr>
                            <th scope="row">2</th>
                            <th scope="row">DhruvinKhadela@gmail.Com</th>
                            <td><i class="fa-solid fa-share"></i></td>
                             
                            
                        </tr>
                      
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>

</html>