<!DOCTYPE html>

<html lang="en">

<head>
    <?php

    include_once './AdminLink.php';
    include_once 'AdminHome.php';

    ?>

</head>



<body>




    <div class="content-wrapper bg-white">
        <div class="content-header mt-5">

            <div class="container-fluid">

                <div class="row d-flex center mb-3">

                    <h1 style="color:black;">Change Password</h1>


                </div>

                <form id="quickForm">
                    <div class="card-body">

                        <div class="form-group">
                            <label>Current Password</label>
                            <input type="Password" name="password" class="form-control" placeholder="Enter Current Password">
                        </div>
                        <div class="form-group">
                            <label>New Password</label>
                            <input type="Password" name="password" class="form-control" placeholder="Enter New Password">
                        </div>
                        <div class="form-group">
                            <label>Confirm Password</label>
                            <input type="Password" name="cpassword" class="form-control" placeholder="Enter Confirm Password">
                        </div>


                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer text-center">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>

        </div>
    </div>









</body>

</html>